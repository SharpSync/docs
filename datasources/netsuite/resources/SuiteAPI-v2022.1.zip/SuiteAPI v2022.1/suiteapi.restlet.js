/**
* @NApiVersion 2.1
* @NScriptType Restlet
* @NModuleScope Public
*/

/* 

------------------------------------------------------------------------------------------
Script Information
------------------------------------------------------------------------------------------

Name:
SuiteAPI

ID:
_suiteapi

Description
An alternative Web API for the NetSuite platform.

Documentation, Support, etc.
https://suiteapi.com


------------------------------------------------------------------------------------------
MIT License
------------------------------------------------------------------------------------------

Copyright (c) 2022 Timothy Dietrich.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.


------------------------------------------------------------------------------------------
Developer(s)
------------------------------------------------------------------------------------------

TD:
• Tim Dietrich
• timdietrich@me.com
• https://timdietrich.me


------------------------------------------------------------------------------------------
History
------------------------------------------------------------------------------------------

20221115 - TD
• Initial public release.

*/


define( [ 'N/config', 'N/email', 'N/encode', 'N/error', 'N/file', 'N/format', 'N/log', 'N/query', 'N/record', 'N/render', 'N/runtime', 'N/search' ], main );


function main( config, email, encode, error, file, format, log, query, record, render, runtime, search ) {


    return {
    	get: getProcess,
        post: postProcess
    }
    
    
	function configGet() {
	
		// Disabled by default. See comments on SuiteAPI.com.
		var customError = error.create(
			{
				name: 'DISABLED',
				message: 'This procedure has been disabled.',
				notifyOff: false
			}

		);		

		throw customError;			
					
		var configInfo = {}
		configInfo.userPreferences = config.load( { type: config.Type.USER_PREFERENCES } );
		configInfo.companyInfo = config.load( { type: config.Type.COMPANY_INFORMATION } );
		configInfo.companyPreferences = config.load( { type: config.Type.COMPANY_PREFERENCES } );
		configInfo.accountingPreferences = config.load( { type: config.Type.ACCOUNTING_PREFERENCES } );
		configInfo.accountingPeriods = config.load( { type: config.Type.ACCOUNTING_PERIODS } );
		configInfo.taxPeriods = config.load( { type: config.Type.TAX_PERIODS } );
		configInfo.features = config.load( { type: config.Type.FEATURES } );
		
		var response = {};
		response.config = configInfo;			
	
		return response;		

	}   

	
	function emailSend( request ) {	
	
		if ( ( typeof request.author == 'undefined' ) || ( request.author === null ) || ( request.author === '' ) ) {		
		
			var customError = error.create(
				{
					name: 'MISSING_PARAMETER',
					message: 'No author was specified.',
					notifyOff: false
				}
	
			);		

			throw customError;			
		
		}
		
		if ( 
				( typeof request.recipients == 'undefined' ) 
				|| ( request.recipients === null ) 
				|| ( ! Array.isArray( request.recipients ) )
				|| ( request.recipients.length == 0 )
			) {		
			
			var customError = error.create(
				{
					name: 'MISSING_PARAMETER',
					message: 'No recipients were specified.',
					notifyOff: false
				}
	
			);		

			throw customError;				
		
		}	
		
		if ( ( typeof request.subject == 'undefined' ) || ( request.subject === null ) ) {		
		
			var customError = error.create(
				{
					name: 'MISSING_PARAMETER',
					message: 'No subject was specified.',
					notifyOff: false
				}
	
			);		

			throw customError;			
					
		}	
		
		if ( ( typeof request.body == 'undefined' ) || ( request.body === null ) ) {
		
			var customError = error.create(
				{
					name: 'MISSING_PARAMETER',
					message: 'No body was specified.',
					notifyOff: false
				}
	
			);		

			throw customError;			

		}		
	
		if ( ( typeof request.attachments != 'undefined' ) && ( request.attachments !== null ) ) {	
			var attachments = [];
			for ( var i = 0; i < request.attachments.length; i++ ) { 	
				var fileID = request.attachments[i];				
				var fileObj = file.load( { id: fileID } );				
				attachments.push( fileObj );			
			}		
			request.attachments = attachments;				
		}		

		email.send( request );
		
		var response = {};
		response.email = {};			
		response.email = request;
		response.email.status = 'sent';	
	
		return response;
		

	}	
	
	
	function eventLog( request ) {
	
		// Valid logName values: audit, debug, emergency, error
		if ( ( typeof request.logName == 'undefined' ) || ( request.logName === null ) || ( request.logName === '' ) ) {
		
			var customError = error.create(
				{
					name: 'MISSING_PARAMETER',
					message: 'No logName was specified.',
					notifyOff: false
				}
	
			);		

			throw customError;			
		
		}	
	
		if ( ( typeof request.title == 'undefined' ) || ( request.title === null ) || ( request.title === '' ) ) {
		
			var customError = error.create(
				{
					name: 'MISSING_PARAMETER',
					message: 'No title was specified.',
					notifyOff: false
				}
	
			);		

			throw customError;			
		
		}	
		
		if ( ( typeof request.details == 'undefined' ) || ( request.details === null ) ) {
		
			var customError = error.create(
				{
					name: 'MISSING_PARAMETER',
					message: 'No details was specified.',
					notifyOff: false
				}
	
			);		

			throw customError;		
				
		}			
	
		// log.debug( { title: request.title, details: request.details } );
		
		log[request.logName.toLowerCase()]( { title: request.title, details: request.details } );
		
		var response = {};
		response.event = {};			
		response.event = request;
		response.event.status = 'logged';	
	
		return response;		
		
	}	
	
	
	function fileCopy( request ) {
	
		if ( ( typeof request.id == 'undefined' ) || ( request.id === null ) || ( request.id === '' ) ) {

			var customError = error.create(
				{
					name: 'MISSING_PARAMETER',
					message: 'No id was specified.',
					notifyOff: false
				}
	
			);		

			throw customError;
		
		}
		
		if ( ( typeof request.folderID == 'undefined' ) || ( request.folderID === null ) || ( request.folderID === '' ) ) {
		
			var customError = error.create(
				{
					name: 'MISSING_PARAMETER',
					message: 'No folderID was specified.',
					notifyOff: false
				}
	
			);		

			throw customError;			
				
		}		
		
		var fileObj = file.copy(
			{
				id: request.id,
				folder: request.folderID,
				conflictResolution: request.conflictResolution
			}
		);
		
		var response = {};
		response.file = {};
		response.file.info = fileObj;	
		
		return response;	
	
	}
	
	
	function fileCreate( request ) {
			
		if ( ( typeof request.name == 'undefined' ) || ( request.name === null ) || ( request.name === '' ) ) {
		
			var customError = error.create(
				{
					name: 'MISSING_PARAMETER',
					message: 'No name was specified.',
					notifyOff: false
				}
	
			);		

			throw customError;			
		
		}	
		
		if ( ( typeof request.fileType == 'undefined' ) || ( request.fileType === null ) || ( request.fileType === '' ) ) {
		
			var customError = error.create(
				{
					name: 'MISSING_PARAMETER',
					message: 'No fileType was specified.',
					notifyOff: false
				}
	
			);		

			throw customError;			
		
		}		
		
		if ( ( typeof request.contents == 'undefined' ) || ( request.contents === null ) ) {
		
			var customError = error.create(
				{
					name: 'MISSING_PARAMETER',
					message: 'No contents were specified.',
					notifyOff: false
				}
	
			);		

			throw customError;			
	
		}	
		
		if ( ( typeof request.description == 'undefined' ) || ( request.description === null ) ) {
		
			var customError = error.create(
				{
					name: 'MISSING_PARAMETER',
					message: 'No description was specified.',
					notifyOff: false
				}
	
			);		

			throw customError;			
		
		}	
		
		if ( ( typeof request.encoding == 'undefined' ) || ( request.encoding === null ) ) {
		
			var customError = error.create(
				{
					name: 'MISSING_PARAMETER',
					message: 'No encoding was specified.',
					notifyOff: false
				}
	
			);		

			throw customError;			
		
		}	
		
		if ( ( typeof request.folderID == 'undefined' ) || ( request.folderID === null ) || ( request.folderID === '' ) ) {
		
			var customError = error.create(
				{
					name: 'MISSING_PARAMETER',
					message: 'No folderID was specified.',
					notifyOff: false
				}
	
			);		

			throw customError;			
				
		}								
	
		if ( ( typeof request.isOnline == 'undefined' ) || ( request.isOnline === null ) || ( request.isOnline === '' ) ) {
			request.isOnline = false;
		}	
		
		if ( ( typeof request.isInactive == 'undefined' ) || ( request.isInactive === null ) || ( request.isOisInactivenline === '' ) ) {
			request.isInactive = false;
		}						
				
		var fileObj = file.create( 
			{
				name: request.name,
				fileType: request.fileType,
				contents: request.contents,
				description: request.description,
				encoding: request.encoding,
				folder: request.folderID,
				isOnline: request.isOnline,
				isInactive: request.isInactive
			} 
		);
	
		var fileID = fileObj.save();
	
		fileObj = file.load( { id: fileID } );
	
		var response = {};
		response.file = {};
		response.file.info = fileObj;

		if ( ( typeof request.returnContent != 'undefined' ) && ( request.returnContent === true ) ) {		

			var contents = fileObj.getContents();
		
			contents = encode.convert(
				{
					string: contents,
					inputEncoding: encode.Encoding.UTF_8,
					outputEncoding: encode.Encoding.BASE_64
				}
			);		
		
			response.file.content = contents;	
	
		}

		return response;				
	
	}
	
	
	function fileDelete( request ) {

		if ( ( typeof request.id == 'undefined' ) || ( request.id === null ) || ( request.id === '' ) ) {
		
			var customError = error.create(
				{
					name: 'MISSING_PARAMETER',
					message: 'No id was specified.',
					notifyOff: false
				}
	
			);		

			throw customError;			

		}	
		
		var fileObj = file.load( { id: request.id } );
	
		var response = {};
		response['info'] = fileObj;
		response['content'] = fileObj.getContents();	
	
		file.delete( { id: request.id } );

		return response;				
	
	}		
	
	
	function fileGet( request ) {

		if ( ( typeof request.id == 'undefined' ) || ( request.id === null ) ) {

			var customError = error.create(
				{
					name: 'MISSING_PARAMETER',
					message: 'No id was specified.',
					notifyOff: false
				}
	
			);		

			throw customError;
	
		}	
		
		if ( ( typeof request.returnContent == 'undefined' ) || ( request.returnContent === null ) ) {
			request.returnContent = true;
		}
				
		var fileObj = file.load( { id: request.id } );
		
		var response = {};
		response.file = {};
		response.file.info = fileObj;
		
		if ( request.returnContent ) {
		
			var contents = fileObj.getContents();
		
			contents = encode.convert(
				{
					string: contents,
					inputEncoding: encode.Encoding.UTF_8,
					outputEncoding: encode.Encoding.BASE_64
				}
			);		
		
			response.file.content = contents;	
			
		}

		return response;				
	
	}	
	
	
	function fileUpdate( request ) {		

		if ( ( typeof request.id == 'undefined' ) || ( request.id === null ) || ( request.id === '' ) ) {

			var customError = error.create(
				{
					name: 'MISSING_PARAMETER',
					message: 'No id was specified.',
					notifyOff: false
				}
	
			);		

			throw customError;
		
		}	
	
		var fileObj = file.load( { id: request.id } );	

		if ( typeof request.name !== 'undefined' ) {
			fileObj.name = request.name;
		}
		
		if ( typeof request.description !== 'undefined' ) {
			fileObj.description = request.description;
		}
		
		if ( typeof request.encoding !== 'undefined' ) {
			fileObj.encoding = request.encoding;
		}	
		
		if ( typeof request.isOnline !== 'undefined' ) {
			fileObj.isOnline = request.isOnline;
		}	
		
		if ( typeof request.isInactive !== 'undefined' ) {
			fileObj.isInactive = request.isInactive;
		}				

		fileObj.save();				
	
		var response = {};
		response.file = {};
		response.file.info = fileObj;
		
		if ( ( typeof request.returnContent != 'undefined' ) && ( request.returnContent === true ) ) {		

			var contents = fileObj.getContents();
		
			contents = encode.convert(
				{
					string: contents,
					inputEncoding: encode.Encoding.UTF_8,
					outputEncoding: encode.Encoding.BASE_64
				}
			);		
		
			response.file.content = contents;	
	
		}

		return response;				
	
	}	
	
	
	function folderCreate( request ) {

		if ( ( typeof request.name == 'undefined' ) || ( request.name === null ) ) {
		
			var customError = error.create(
				{
					name: 'MISSING_PARAMETER',
					message: 'No name was specified.',
					notifyOff: false
				}
	
			);		

			throw customError;				
							
		}	
	
		var folderRecord = record.create( 
			{ 
				type: record.Type.FOLDER, 
				isDynamic: false 
			} 
		);
	
		folderRecord.setValue( { fieldId: 'name', value: request.name } );	
		
		if ( typeof request.description !== 'undefined' ) {
			folderRecord.setValue( { fieldId: 'description', value: request.description } );
		}
		
		if ( typeof request.isPrivate !== 'undefined' ) {		
			folderRecord.setValue( { fieldId: 'isprivate', value: request.isPrivate } );
		}
		
		if ( typeof request.isInactive !== 'undefined' ) {
			folderRecord.setValue( { fieldId: 'isinactive', value: request.isInactive } );
		}			
		
		if ( typeof request.parent !== 'undefined' ) {
			folderRecord.setValue( { fieldId: 'parent', value: request.parent } );
		}
	
		var folderID = folderRecord.save( { enableSourcing: false, ignoreMandatoryFields: true } );			
	
		var response = record.load( { type: record.Type.FOLDER, id: folderID } );
	
		return response;			
	
	}	
	
	
	function folderDelete( request ) {

		if ( ( typeof request.id == 'undefined' ) || ( request.id === null ) ) {
		
			var customError = error.create(
				{
					name: 'MISSING_PARAMETER',
					message: 'No id was specified.',
					notifyOff: false
				}
	
			);		

			throw customError;			

		}	
	
		record.delete( { type: record.Type.FOLDER, id: request.id } );
	
		return { 'status': 'deleted' }		

	}	
	
	
	function folderUpdate( request ) {

		if ( ( typeof request.id == 'undefined' ) || ( request.id === null ) ) {
		
			var customError = error.create(
				{
					name: 'MISSING_PARAMETER',
					message: 'No id was specified.',
					notifyOff: false
				}
	
			);		

			throw customError;			
		
		}	
	
		var folderRecord = record.load( { type: record.Type.FOLDER, id: request.id } );
	
		if ( ( typeof request.name !== 'undefined' ) || ( request.name !== null ) ) {
			folderRecord.setValue( { fieldId: 'name', value: request.name } );
		}
		
		if ( typeof request.description !== 'undefined' ) {
			folderRecord.setValue( { fieldId: 'description', value: request.description } );
		}		
		
		if ( typeof request.isPrivate !== 'undefined' ) {
			folderRecord.setValue( { fieldId: 'isprivate', value: request.isPrivate } );
		}		
		
		if ( typeof request.isInactive !== 'undefined' ) {
			folderRecord.setValue( { fieldId: 'isinactive', value: request.isInactive } );
		}
	
		folderRecord.save( { enableSourcing: false, ignoreMandatoryFields: true } );	
	
		return folderRecord;		

	}	


	function getProcess( request ) {	
	
		try {
	
			var customError = error.create(
				{
					name: 'UNSUPPORTED_METHOD',
					message: 'GET requests are not supported',
					notifyOff: false
				}
	
			);		

			throw customError;	
			
		} catch( e ) {		
			
			log.error( { title: 'error', details: e } );				

			return e;
			
		}					
		
	}
	
	
	function postProcess( request ) {	
			
		try {
		
			if ( ( typeof request.procedure == 'undefined' ) || ( request.procedure === null ) ) {		
		
				var customError = error.create(
					{
						name: 'MISSING_PROCEDURE',
						message: 'No procedure was specified.',
						notifyOff: false
					}
				
				);		
			
				throw customError;
		
			}
		
			switch ( request.procedure ) {
	
				case 'configGet':
					return configGet();
					
				case 'echo':
					return request;

				case 'emailSend':
					return emailSend( request );	
					
				case 'eventLog':
					return eventLog( request );
	
				case 'fileCopy':
					return fileCopy( request );					
					
				case 'fileCreate':
					return fileCreate( request );
					
				case 'fileDelete':
					return fileDelete( request );
					
				case 'fileEnumerate':
					return file;		
					
				case 'fileGet':
					return fileGet( request );	
					
				case 'fileUpdate':
					return fileUpdate( request );	
					
				case 'folderCreate':
					return folderCreate( request );	
					
				case 'folderDelete':
					return folderDelete( request );		
					
				case 'folderUpdate':
					return folderUpdate( request );	
					
				case 'queryEnumerate':
					return query;																				
					
				case 'queryRun':
					return queryRun( request );					
					
				case 'recordEnumerate':
					return record;		
					
				case 'recordGet':
					return recordGet( request );	
					
				case 'renderEnumerate':
					return render;	
				
				case 'requestEcho':
					return request;
					
				case 'runtimeGet':
					return runtimeGet();

				case 'searchRun':
					return searchRun( request );
					
				case 'transactionCreate':
					return transactionCreate( request );
										
				case 'transactionRender':
					return transactionRender( request );						
					
				case 'xmlRender':
					return xmlRender( request );					

				default:		
				
					var customError = error.create(
						{
							name: 'UNSUPPORTED_PROCEDURE',
							message: `The specified procedure (${request.procedure}) is not supported.`,
							notifyOff: false
						}
				
					);			
					
					throw customError;
	
			}
		
		} catch( e ) {		
			
			log.error( { title: 'error', details: e } );				

			return e;
			
		}		
		
	}     
	
	
	function queryRun( request ) {

		if ( ( typeof request.query == 'undefined' ) || ( request.query === null ) || ( request.query === '' ) ) {
		
			var customError = error.create(
				{
					name: 'MISSING_PARAMETER',
					message: 'No query was specified.',
					notifyOff: false
				}
	
			);		

			throw customError;			

		}	
	
		if ( typeof request.params == 'undefined' ) {
			request.params = new Array();
		}
	
		var records = query.runSuiteQL( 
			{
				query: request.query,
				params: request.params
			}		
		).asMappedResults();	
		
		return { 
			'records': records
		}					
		
	} 	
	
	
	function recordGet( request ) {	

		if ( ( typeof request.type == 'undefined' ) || ( request.type === null ) ) {
		
			var customError = error.create(
				{
					name: 'MISSING_PARAMETER',
					message: 'No type was specified.',
					notifyOff: false
				}
	
			);		

			throw customError;		
	
		}	
	
		if ( ( typeof request.id == 'undefined' ) || ( request.id === null ) ) {
		
			var customError = error.create(
				{
					name: 'MISSING_PARAMETER',
					message: 'No id was specified.',
					notifyOff: false
				}
	
			);		

			throw customError;	
			
		}	
	
		var response = {};
		response.record = record.load( { type: request.type, id: request.id, isDynamic: false } );	

		return response;	
	
	} 

	
	function runtimeGet() {
		
		var runtimeInfo = {}
		runtimeInfo.accountId = runtime.accountId;
		runtimeInfo.envType = runtime.envType;
		runtimeInfo.executionContext = runtime.executionContext;
		runtimeInfo.processorCount = runtime.processorCount;
		runtimeInfo.queueCount = runtime.queueCount;
		runtimeInfo.version = runtime.version;	
		runtimeInfo.currentScript = runtime.getCurrentScript();
		runtimeInfo.currentSession = runtime.getCurrentSession();
		runtimeInfo.currentUser = runtime.getCurrentUser();		
		return runtimeInfo;
	
	}	
	
	
	function searchRun( request ) {

		if ( ( typeof request.id == 'undefined' ) || ( request.id === null ) || ( request.id === '' ) ) {
		
			var customError = error.create(
				{
					name: 'MISSING_PARAMETER',
					message: 'No ID was specified.',
					notifyOff: false
				}
	
			);		

			throw customError;			
	
		}

		var searchObj = search.load( { id: request.id } );

		var allResults = [];

		var resultSet = searchObj.run();

		var start = 0;

		var results = [];

		do {
	
			results = resultSet.getRange( 
				{
					start: start, 
					end: start + 1000
				} 
			);
		
			start += 1000;
		
			allResults = allResults.concat( results ) ;
		
		} while ( results.length );

		return allResults;

	}	


	function transactionRender( request ) {
	
		if ( ( typeof request.transactionType == 'undefined' ) || ( request.transactionType === null ) || ( request.transactionType === '' ) ) {
		
			var customError = error.create(
				{
					name: 'MISSING_PARAMETER',
					message: 'No transactionType was specified.',
					notifyOff: false
				}
	
			);		

			throw customError;			
	
		}
		
		if ( ( typeof request.id == 'undefined' ) || ( request.id === null ) || ( request.id === null ) ) {
		
			var customError = error.create(
				{
					name: 'MISSING_PARAMETER',
					message: 'No ID was specified.',
					notifyOff: false
				}
	
			);		

			throw customError;			
	
		}
		
		if ( ( typeof request.printMode == 'undefined' ) || ( request.printMode === null ) || ( request.printMode === '' ) ) {
		
			var customError = error.create(
				{
					name: 'MISSING_PARAMETER',
					message: 'No printMode was specified.',
					notifyOff: false
				}
	
			);		

			throw customError;			
	
		}	

		var pdfFile = null;
	
		pdfFile = render.transaction(
			{
				entityId: request.id,
				printMode: request.printMode,
				formId: request.formId
			}
		);		
	
		var response = {};
		response['info'] = pdfFile;
		response['content'] = pdfFile.getContents();	
	
		return response;	

	}	
	
	
	function xmlRender( request ) {

		if ( ( typeof request.xml == 'undefined' ) || ( request.xml === null ) || ( request.xml === '' ) ) {
		
			var customError = error.create(
				{
					name: 'MISSING_PARAMETER',
					message: 'No XML was specified.',
					notifyOff: false
				}
	
			);		

			throw customError;			
	
		}
	
		pdfFile = render.xmlToPdf( { xmlString: request.xml } );
	
		var response = {};
		response['info'] = pdfFile;
		response['content'] = pdfFile.getContents();	
	
		return response;	
		
	}	


}